<?php
// PayU configuration
// IMPORTANT: Keep this file out of version control if possible.
// Provided credentials
if (!defined('PAYU_KEY')) define('PAYU_KEY', 'TajbFl');
if (!defined('PAYU_SALT')) define('PAYU_SALT', '8UkizXTe06KGzBv2ySnxmPqyTmnwwLBL');
// 'prod' or 'test'
if (!defined('PAYU_ENV')) define('PAYU_ENV', 'prod');

function payu_endpoint() {
  $env = defined('PAYU_ENV') ? PAYU_ENV : 'prod';
  return $env === 'test' ? 'https://test.payu.in/_payment' : 'https://secure.payu.in/_payment';
}
